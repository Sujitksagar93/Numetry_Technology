package com.numetry.login.service;



public class UserService {

}
